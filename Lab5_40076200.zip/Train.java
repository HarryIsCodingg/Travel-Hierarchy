package Practice;

public class Train extends Travel{

	private double trainFare;
	private boolean isSeperateCabin;
	
	Train(int distance, double baseprice,double trainFare, boolean isSeperateCabin) {
		super(distance, baseprice);
		this.trainFare=trainFare;
		this.isSeperateCabin=isSeperateCabin;
	}

	@Override
	public String toString() {
		return "Train [trainFare=" + trainFare + ", isSeperateCabin=" + isSeperateCabin + ", distance=" + distance
				+ ", baseprice=" + baseprice + "]";
	}

	@Override
	public double totalPrice() {
		return (this.baseprice+(this.trainFare*1.3)+100);
	}

	@Override
	public void information() {
		String seperateCabin = "";
		if (this.isSeperateCabin) {
			seperateCabin = "is a seperate cabin";
		} else {
			seperateCabin = "is not a seperate cabin";
		}
		System.out.printf(
				"The distance of the travel is %d kms and it is travel in %s . The train fare is %f$ and the base price is %f$. The total expense of the train travel will be %f$",
				this.distance, seperateCabin, this.trainFare,this.baseprice, this.totalPrice());
		
	}

}
