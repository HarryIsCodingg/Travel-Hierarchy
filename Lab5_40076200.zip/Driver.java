package Practice;

class Driver{
	public static void main(String[] args) {
		
		Airplane[] airplaneArray= {new Airplane(11000,1200,300,true), new Airplane(12000,1100,400,false)};
		Train train1=new Train(150,200,50,true);
		Train train2=new Train(200,400,60,false);
		Travel[] trainArray= {train1,train2 };
		
		for(int i=0;i<trainArray.length;i++) {
			trainArray[i].information();
			System.out.println();
		}
		System.out.println();
		for(Airplane x:airplaneArray) {
			x.information();
			System.out.println();
		}
	}
}