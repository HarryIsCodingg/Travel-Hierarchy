package Practice;

public class Airplane extends Travel {
	int noOfPassengers;
	boolean isBusiness;

	Airplane(int distance, double baseprice, int noOfPassengers, boolean isBusiness) {
		super(distance, baseprice);
		this.noOfPassengers = noOfPassengers;
		this.isBusiness = isBusiness;
	}

	@Override
	public String toString() {
		return "Airplane [noOfPassengers=" + noOfPassengers + ", isBusiness=" + isBusiness + ", distance=" + distance
				+ ", baseprice=" + baseprice + "]";
	}

	public double totalPrice() {
		if (isBusiness) {
			return ((this.baseprice * (2.5) + 1000));
		} else {
			return this.baseprice + 1000;
		}
	}

	public void information() {
		String business = "";
		if (this.isBusiness) {
			business = "business class";
		} else {
			business = "not a business class";
		}
		System.out.printf(
				"The distance of the travel is %d kms and the number of passengers travelling are %d . The base price is %f$ and the airline ticket is %s so the total expense is %f$ ",
				this.distance, this.noOfPassengers, this.baseprice,business, this.totalPrice());
	}

}
