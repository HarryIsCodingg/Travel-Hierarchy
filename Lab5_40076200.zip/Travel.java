package Practice;

public abstract class Travel {
	public int distance;
	public double baseprice;
	
	public Travel(int distance, double baseprice){
		this.distance=distance;
		this.baseprice=baseprice;
	}
	
	@Override
	public String toString() {
		return "Travel [distance=" + distance + ", baseprice=" + baseprice + "]";
	}
	public abstract double totalPrice();
	public abstract void information();
	
	public void setDistance(int distance) {
		this.distance=distance;
	}
}
